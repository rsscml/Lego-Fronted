import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chang-password',
  templateUrl: './chang-password.component.html',
  styleUrls: ['./chang-password.component.css']
})
export class ChangPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
